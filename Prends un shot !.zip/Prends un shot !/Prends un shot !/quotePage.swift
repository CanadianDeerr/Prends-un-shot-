//
//  quotePage.swift
//  Prends un shot !
//
//  Created by Corentin Bringer on 23/10/2018.
//  Copyright © 2018 Corentin Bringer. All rights reserved.
//

import UIKit

class quotePage: UIViewController {
    //Les types de verre
    let typeVerre = [" un shot", "2 shots", "3 shots", "un barril", "une citerne", "une carafe"]
    //Les types d'alcools
    let typeAlcool = ["vodka", "rhum", "bière", "ricard", "pastis", "whisky"]
    
    @IBOutlet weak var quoteLabel: UILabel!
    @IBAction func changeQuote() {
        //Choisir un type de verre en random
        let randomIndex1 = Int(arc4random_uniform(UInt32(typeVerre.count)))
        let verre = typeVerre[randomIndex1]
        
        //Choisir un type d'alcool en random
        let randomIndex2 = Int(arc4random_uniform(UInt32(typeAlcool.count)))
        let alcool = typeAlcool[randomIndex2]
        
        //Affichage de la phrase
        quoteLabel.text = "Prends "+verre+" de "+alcool+" !"
    }
}
